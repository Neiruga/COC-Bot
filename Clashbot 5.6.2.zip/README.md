# Clash of Clans Bot
A Free/Open Sourced Clash of Clans bot - https://the.bytecode.club

How to Start Bot - https://the.bytecode.club/showthread.php?tid=1067

How to Report Bug/Help - https://the.bytecode.club/showthread.php?tid=1075